<div class="widget widget-post">
							<h3 class="widgettitle">Latest Fixtures</h3>
					
<?php 
$querylimitresults=mysqli_query($con,"select * from tblpagelimits WHERE id='9'");
$rowlimitresults=mysqli_fetch_array($querylimitresults);
$limitresultstab = $rowlimitresults['Limits'];
$query=mysqli_query($con,"select * from tblmatchup WHERE Is_Active=1 order by id desc LIMIT $limitresultstab");
while($rowg=mysqli_fetch_array($query))
{
if ($rowg['Result'] == 'LOSS'){
$fontcolor = '7';
} else If ($rowg['Result'] == 'WIN')
{
$fontcolor = '6';
} else {
$fontcolor = '8';
}
?>
<?php
if ($rowg['Result'] == 'LOSS'){
$fontcolor2 = '#D22B20';
} else If ($rowg['Result'] == 'WIN')
{
$fontcolor2 = 'green';
} else {
$fontcolor2 = '#0047AB';
}
?>
<p class="mt-4"> 
<center>
<aside id="sidebar01">

                              <img src="admin/postimages/<?php echo $row1['ClanLogo'];?>" width="30" height="30">
                              <font color ="#111" size="2"><b><?php echo $row1['ClanName'];?></b></font>
                              <font color ="#111" size="2">&nbsp;&nbsp;vs&nbsp;&nbsp;</font>
                              <font color ="#111" size="2"><b><?php echo $rowg['Enemy'];?></b></font>
                              <img src="admin/postimages/<?php echo $rowg['PostImage'];?>" width="30" height="30"><br>
                              <font color="<?php echo $fontcolor2;?>" size="2" style="font-weight:bold"><?php echo $rowg['Time'];?></font>

</aside>
</center>
</p>
<?php } ?>                     
						</div>