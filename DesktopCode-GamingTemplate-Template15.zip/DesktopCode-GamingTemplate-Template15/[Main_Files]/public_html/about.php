<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query=mysqli_query($con,"select ClanName from tblsettings WHERE id=1");
$rowclan=mysqli_fetch_array($query);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
   <meta charset="utf-8">
   <title><?php echo $row1['SiteTitle'];?></title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<head>
	<title>Tanajil - Blog List</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png"/>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<link rel="stylesheet" href="assets/css/jquery-ui.css">
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" href="assets/css/chosen.min.css">
	<link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css">
	<link rel="stylesheet" href="assets/css/magnific-popup.min.css">
	<link rel="stylesheet" href="assets/css/lightbox.min.css">
	<link rel="stylesheet" href="assets/js/fancybox/source/jquery.fancybox.css">
	<link rel="stylesheet" href="assets/css/jquery.scrollbar.min.css">
	<link rel="stylesheet" href="assets/css/mobile-menu.css">
	<link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
	<link rel="stylesheet" href="assets/css/style.css">
                  <link rel="stylesheet" href="assets/css/01.css">
                  <link href="assets/css/w3.css" rel="stylesheet" type="text/css" />
                  <link href="assets/css/matches.css" rel="stylesheet" type="text/css" />

<!--Favicon-->
  <link rel="shortcut icon" href="admin/postimages/<?php echo $row1['favicon'];?>" type="image/x-icon">
  <link rel="icon" href="admin/postimages/<?php echo $row1['favicon'];?>" type="image/x-icon">

   <!-- Font -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
</head>
<body class="inblog-page">
	<header class="header style7">
		<div class="top-bar">
			<div class="container">
				<div class="top-bar-left">
					<div class="header-message">
<ul class="tanajil-clone-mobile-menu tanajil-nav main-menu" id="menu-main-menu">
<center>
<?php 
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="3" color="#fff"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"><i class="fa fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
}
?>
</center>
</ul>
					</div>
				</div>
				<div class="top-bar-right">	
				<div class="header-control">
							<a class="menu-bar mobile-navigation menu-toggle" href="#">
								<span></span>
								<span></span>
								<span></span>
							</a>
						</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="main-header">
				<div class="row">
					<div class="col-lg-12 col-sm-4 col-md-3 col-xs-7 col-ts-12 header-element">
						<div class="logo" style="margin-bottom:-50px;margin-top:-50px;">
							
								<img src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-left:2px solid black;border-right:2px solid black; width:1200px; height:200px;" class="img-responsive">
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="header-nav-container">
			<div class="container">
				<div class="header-nav-wapper main-menu-wapper">
					<div class="vertical-wapper block-nav-categori">
						<div class="block-title">
						<span class="icon-bar">
							<span></span>
							<span></span>
							<span></span>
						</span>
							<span class="text">MENU</span>
						</div>
						
					</div>
					<div class="header-nav">
						<div class="container-wapper">
							<ul class="tanajil-clone-mobile-menu tanajil-nav main-menu " id="menu-main-menu">
							<li class="menu-item">
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<a href="<?php echo $row['Description'];?>"><?php echo $row['HeaderName'];?></a>
<?php
}
?>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="header-device-mobile">
		<div class="wapper">
			<div class="item mobile-logo">
				<div class="col-lg-12 col-sm-4 col-md-3 col-xs-7 col-ts-12 header-element">
						<div class="logo" style="margin-bottom:-50px;margin-top:-50px;">
					<img src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border:2px solid black; width:1200px; height:200px;" class="img-responsive">
				</div></div>
			</div>
			<div class="item item mobile-search-box has-sub">
				<a href="#">
						<span class="icon">
							<i class="fa fa-search" aria-hidden="true"></i>
						</span>
				</a>
				<div class="block-sub">
					<a href="#" class="close">
						<i class="fa fa-times" aria-hidden="true"></i>
					</a>
					<div class="header-searchform-box">
						<form class="header-searchform">
							<div class="searchform-wrap">
								<input type="text" class="search-input" placeholder="Enter keywords to search...">
								<input type="submit" class="submit button" value="Search">
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="item mobile-settings-box has-sub">
				<a href="#">
						<span class="icon">
							<i class="fa fa-cog" aria-hidden="true"></i>
						</span>
				</a>
				<div class="block-sub">
					<a href="#" class="close">
						<i class="fa fa-times" aria-hidden="true"></i>
					</a>
					
				</div>
			</div>
			<div class="item menu-bar">
				<a class=" mobile-navigation  menu-toggle" href="#">
					<span></span>
					<span></span>
					<span></span>
				</a>
			</div>
		</div>
	</div>
	<div class="main-content main-content-blog list right-sidebar">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="breadcrumb-trail breadcrumbs">
						<ul class="trail-items breadcrumb">
							<li class="trail-item trail-begin">
								<a href="index.php"><font style="font-size:15px;">Home</font></a>
							</li>
							<li class="trail-item trail-end active">
								<a href="about.php"><font style="font-size:15px;">About Page</font></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="content-area content-blog col-lg-9 col-md-8 col-sm-12 col-xs-12">
					<div class="site-main">
						<h3 class="widgettitle">About Us</h3>
								
<?php 
$query=mysqli_query($con,"select * from tblabout WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>

<center>
<aside id="sidebar01" style="margin-top:0px;">
<img class="img-responsive" src="admin/postimages/<?php echo $row['ClanPic'];?>" width="300" height="125"/><br><br>
<h3><font size="5" color="black"><b><?php echo $row['AboutTitle'];?></b></font></h3>
<p><font color="black"><h4 style="padding-left:10px; padding-right:10px;"><?php echo $row['About1'];?></h4></font></p>
<p><font color="black"><h4 style="padding-left:10px; padding-right:10px;"><?php echo $row['About2'];?></h4></font></p>
<p><font color="black"><h4 style="padding-left:10px; padding-right:10px;"><?php echo $row['About3'];?></h4></font></p>
</aside>
<?php } ?>
</font>
</center>


					</div>
				</div>
				<div class="sidebar sidebar-blog col-lg-3">
					<div class="wrapper-sidebar">
<?php include 'account.php';?>
					
<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Top'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?>  
						
							   <?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Bottom'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?>  
						
						
			</div>
		</div>
	</div>
	<footer class="footer style7" style="margin-top:50px;">
		<div class="container">
			<div class="container-wapper">
				<div class="row">
					
				<div class="footer-end">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="coppyright">
				Copyright © 2024 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="tanajil-payment">
						<?php 
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4" color="white"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"><i class="fa fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
}
?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
	<script src="assets/js/jquery-1.12.4.min.js"></script>
	<script src="assets/js/jquery.plugin-countdown.min.js"></script>
	<script src="assets/js/jquery-countdown.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/magnific-popup.min.js"></script>
	<script src="assets/js/isotope.min.js"></script>
	<script src="assets/js/jquery.scrollbar.min.js"></script>
	<script src="assets/js/jquery-ui.min.js"></script>
	<script src="assets/js/mobile-menu.js"></script>
	<script src="assets/js/chosen.min.js"></script>
	<script src="assets/js/slick.js"></script>
	<script src="assets/js/jquery.elevateZoom.min.js"></script>
	<script src="assets/js/jquery.actual.min.js"></script>
	<script src="assets/js/fancybox/source/jquery.fancybox.js"></script>
	<script src="assets/js/lightbox.min.js"></script>
	<script src="assets/js/owl.thumbs.min.js"></script>
	<script src="assets/js/jquery.scrollbar.min.js"></script>
	<script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM'></script>
	<script src="assets/js/frontend-plugin.js"></script>
</body>

<!-- tanajil/bloglist.html  21 Nov 2019 03:35:36 GMT -->
</html>