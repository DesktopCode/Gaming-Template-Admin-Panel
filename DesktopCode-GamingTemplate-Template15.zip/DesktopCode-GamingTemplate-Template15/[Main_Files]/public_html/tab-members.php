<div class="widget widget-post">
<h3 class="widgettitle">Team Members</h3>
<div class="col-lg-12">	
<?php
$id=intval($_GET['id']);
$queryx=mysqli_query($con,"select id, glogo, GameName from tblgames WHERE Is_Active='1'");
while($rowx=mysqli_fetch_array($queryx)) {
$game = $rowx['GameName'];
$glogo = $rowx['glogo'];
?>

<center>
<div style="margin-top:10px;"> 
<button onclick="myFunction('<?php echo $game;?>')" class="w3-button" style="width:100%; height:40%;">
<font size="4" style="margin-left:10px;color:black;"><?php echo $game;?> <font color="#f52626">▼</font></font></button>
</div><hr>
</center>
<div id="<?php echo $game;?>" class="w3-hide">
<?php
$queryc=mysqli_query($con,"SELECT * FROM tblteam where Game='$game' LIMIT 10");
while($rowc=mysqli_fetch_array($queryc)){
?>
<center>
<a href="member.php?name=<?php echo htmlentities($rowc['Alias'])?>"><img class="img-responsive" src="admin/postimages/<?php echo $rowc['Avatar'];?>" style="border-radius:5px;margin-top:5px;width:100px; height:100px;">
<font size="4" color="black" style="text-shadow: 1px 1px 1px black;"><b><?php echo $rowc['Alias'];?></b></font></a>
</center>
<?php
} 
?>
</div>
<?php
} 
?>
</div>
<script>
function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>
</div>
</div>