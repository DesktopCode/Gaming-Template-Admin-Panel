<div class="widget widget-post">
							<h3 class="widgettitle">News Articles</h3>
<?php
$querylimit=mysqli_query($con,"select * from tblpagelimits WHERE id='11'");
$rowlimit=mysqli_fetch_array($querylimit);

     if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = $rowlimit['Limits'];
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblposts";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId order by tblposts.id desc  LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
?>
<?php
$pid = $row['pid'];
$total_comments = "SELECT COUNT(*) FROM tblcomments WHERE postId=$pid";
$comresult2 = mysqli_query($con,$total_comments);
$comresult = mysqli_fetch_array($comresult2)[0];
?>
<aside id="sidebar01" style="margin-bottom:-10px;">
							<ul class="tanajil-posts">
								<li class="widget-post-item">
									<div class="thumb-blog">
										<a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"><img src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>" class="img-fluid" style="width:100px; height:70px; border-radius:5px;" alt=""></a>
									</div>
									<div class="post-content">
										<div class="cat">
                                                                                                                                                                                    <h5 class="post-title"><a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"><?php $pts=$row['posttitle']; echo  (substr($pts,0,14));?>...</a></h5>
                                                                                                                                                                                     <br><font style="size:10px;"><i class="fa fa-comments"></i> <?php echo $comresult;?> Comments</font>
										<br><font style="size:10px;"><i class="fa fa-calendar"></i> <?php echo htmlentities($row['postingdate']);?></font>
										</div>
									</div>
								</li>
							</ul>
</aside>
<br>
<?php } ?>
						</div>