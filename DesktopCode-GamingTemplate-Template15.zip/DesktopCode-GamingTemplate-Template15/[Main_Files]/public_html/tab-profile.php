<div class="widget widget-post">
<h3 class="widgettitle">Profile Manager</h3>
<aside id="sidebar01">
<?php
if ($r['active'] && $r['username'] == $member) {
?>
                            
		                                                                                           <div class="profilesettings" style="margin-left:30px;">
                                                                                                                               <br>
							 <ul>
                                                                                                                                                <li><font size="5" color="#c70808">»</font> <a href="profile.php?name=<?php echo $member;?>"><b>Profile Page</b></a></li><br>
<li><font size="5" color="#c70808">»</font> <a href="profilefriends.php?name=<?php echo $member;?>"><b>Friends List</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilepm.php?name=<?php echo $member;?>"><b>Private Messages</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilepicture.php?name=<?php echo $member;?>"><b>Profile Picture</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilepostcomments.php?name=<?php echo $member;?>"><b>Post News Comments</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilequeries.php?name=<?php echo $member;?>"><b>Support Queries</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilesettings.php?name=<?php echo $member;?>"><b>Profile Settings</b></a></li><br>
                                                                                                                                                <li><font size="5" color="#c70808">»</font> <a href="editmember.php?name=<?php echo $member;?>"><b>Clan Member Settings</b></a></li>
							</ul>
						                  </div>
                                                                                                                              <br>

<?php } else { ?>

		                                                                         <div class="profilesettings" style="margin-left:20px;"><br>
						 <ul>
                                                                                                                                                <li><font size="5" color="#c70808">»</font> <a href="profile.php?name=<?php echo $member;?>" class="profilenav"><b>Profile Page</b></a></li><br>
								<li><font size="5" color="#c70808">»</font> <a href="profilepostcomments.php?name=<?php echo $member;?>"><b>Post News Comments</b></a></li>
						 </ul>
						 </div>
                                                                                                             <br>
<?php } ?>    
</aside>	
</div>