<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
$querycon=mysqli_query($con,"select * from tblcontact WHERE Is_Active = '1'");
$rowcon=mysqli_fetch_array($querycon);
$querylimitqueries=mysqli_query($con,"select * from tblpagelimits WHERE id='8'");
$rowlimitqueries=mysqli_fetch_array($querylimitqueries);
$member=strval($_GET['name']); 

if (empty($_SESSION['token'])) {
 $_SESSION['token'] = bin2hex(random_bytes(32));
}
if(isset($_POST['submit']))
{
  //Verifying CSRF Token
if (!empty($_POST['csrftoken'])) {
if (hash_equals($_SESSION['token'], $_POST['csrftoken'])) {
$name=$r['username'];
$email=$r['email'];
$comment=$_POST['comment'];
$postid=intval($_GET['nid']);
$st1='1';
$query=mysqli_query($con,"insert into tblcomments(postId,name,email,comment,status) values('$postid','$name','$email','$comment','$st1')");
if($query):
$dellmsg="Comment Successfully Posted";
  unset($_SESSION['token']);
else :
 echo "<script>alert('Something went wrong. Please try again.');</script>";  

endif;

}
}
}

if($_GET['action']=='del' && $_GET['id'])
{
	$id=intval($_GET['id']);
	$query=mysqli_query($con,"delete from tblenquiry where ID='$id'");
	$delmsg="Enquiry Successfully Deleted";
}


if(isset($_POST['updatee']))
{
$emailp=  $_POST['email'];
$query9=mysqli_query($con,"update usermanagement set email='$emailp' where username='$username'");
if($query9)
{
$msg11="Your Email Has Been Updated!";
}
else{
$error11="Something went wrong . Please try again.";    
}
}

if (isset($_POST['updatep']) & ($_POST['password'] != $_POST['password2'])) {
$error12="The Passwords Dont Match!";
}else if(isset($_POST['updatep']) & ($_POST['password'] == $_POST['password2']))
{
$passwordp  = hash('md5', $_POST['password']);
$query99=mysqli_query($con,"update usermanagement set password='$passwordp' where username='$username'");
if($query99)
{
$msg11="Your Password Has Been Changed!";
}
else {
$error11="Something went wrong . Please try again.";
}
}

if(isset($_POST['updates']))
{

$imgfile=$_FILES["postimage"]["name"];
// get the image extension
$extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));
// allowed extensions
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
// Validation for allowed extensions .in_array() function searches an array for a specific value.
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
//rename the image file
$imgnewfile=md5($imgfile).$extension;
// Code for move image into directory
move_uploaded_file($_FILES["postimage"]["tmp_name"],"images/".$imgnewfile);

$member=strval($_GET['name']);
$query=mysqli_query($con,"update usermanagement set profilepic='$imgnewfile' where username='$member'");
if($query)
{
$msg="New Profile Image Updated!";
}
else{
$error="Something Went Wrong! Please Try Again!";
} 
}
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
   <meta charset="utf-8">
   <title><?php echo $row1['SiteTitle'];?></title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<head>
	<title>Tanajil - Blog List</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png"/>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<link rel="stylesheet" href="assets/css/jquery-ui.css">
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" href="assets/css/chosen.min.css">
	<link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css">
	<link rel="stylesheet" href="assets/css/magnific-popup.min.css">
	<link rel="stylesheet" href="assets/css/lightbox.min.css">
	<link rel="stylesheet" href="assets/js/fancybox/source/jquery.fancybox.css">
	<link rel="stylesheet" href="assets/css/jquery.scrollbar.min.css">
	<link rel="stylesheet" href="assets/css/mobile-menu.css">
	<link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
	<link rel="stylesheet" href="assets/css/style.css">
                  <link rel="stylesheet" href="assets/css/01.css">
                  <link href="assets/css/w3.css" rel="stylesheet" type="text/css" />
                  <link href="assets/css/matches.css" rel="stylesheet" type="text/css" />

  <!--Favicon-->
  <link rel="shortcut icon" href="admin/postimages/<?php echo $row1['favicon'];?>" type="image/x-icon">
  <link rel="icon" href="admin/postimages/<?php echo $row1['favicon'];?>" type="image/x-icon">

   <!-- Font -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
   </head>
<body class="inblog-page">
	<header class="header style7">
		<div class="top-bar">
			<div class="container">
				<div class="top-bar-left">
					<div class="header-message">
<ul class="tanajil-clone-mobile-menu tanajil-nav main-menu" id="menu-main-menu">
<center>
<?php 
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="3" color="#fff"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"><i class="fa fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
}
?>
</center>
</ul>
					</div>
				</div>
				<div class="top-bar-right">	
				<div class="header-control">
							<a class="menu-bar mobile-navigation menu-toggle" href="#">
								<span></span>
								<span></span>
								<span></span>
							</a>
						</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="main-header">
				<div class="row">
					<div class="col-lg-12 col-sm-4 col-md-3 col-xs-7 col-ts-12 header-element">
						<div class="logo" style="margin-bottom:-50px;margin-top:-50px;">
						<img src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-left:2px solid black;border-right:2px solid black; width:1200px; height:200px;" class="img-responsive">
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="header-nav-container">
			<div class="container">
				<div class="header-nav-wapper main-menu-wapper">
					<div class="vertical-wapper block-nav-categori">
						<div class="block-title">
						<span class="icon-bar">
							<span></span>
							<span></span>
							<span></span>
						</span>
							<span class="text">MENU</span>
						</div>
						
					</div>
					<div class="header-nav">
						<div class="container-wapper">
							<ul class="tanajil-clone-mobile-menu tanajil-nav main-menu " id="menu-main-menu">
							<li class="menu-item">
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<a href="<?php echo $row['Description'];?>"><?php echo $row['HeaderName'];?></a>
<?php
}
?>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="header-device-mobile">
		<div class="wapper">
			<div class="item mobile-logo">
				<div class="col-lg-12 col-sm-4 col-md-3 col-xs-7 col-ts-12 header-element">
						<div class="logo" style="margin-bottom:-50px;margin-top:-50px;">
					<img src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border:2px solid black; width:1200px; height:200px;" class="img-responsive">
				</div></div>
			</div>
			<div class="item item mobile-search-box has-sub">
				<a href="#">
						<span class="icon">
							<i class="fa fa-search" aria-hidden="true"></i>
						</span>
				</a>
				<div class="block-sub">
					<a href="#" class="close">
						<i class="fa fa-times" aria-hidden="true"></i>
					</a>
					<div class="header-searchform-box">
						<form class="header-searchform">
							<div class="searchform-wrap">
								<input type="text" class="search-input" placeholder="Enter keywords to search...">
								<input type="submit" class="submit button" value="Search">
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="item mobile-settings-box has-sub">
				<a href="#">
						<span class="icon">
							<i class="fa fa-cog" aria-hidden="true"></i>
						</span>
				</a>
				<div class="block-sub">
					<a href="#" class="close">
						<i class="fa fa-times" aria-hidden="true"></i>
					</a>
					
				</div>
			</div>
			<div class="item menu-bar">
				<a class=" mobile-navigation  menu-toggle" href="#">
					<span></span>
					<span></span>
					<span></span>
				</a>
			</div>
		</div>
	</div>
	<div class="main-content main-content-blog list right-sidebar">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="breadcrumb-trail breadcrumbs">
						<ul class="trail-items breadcrumb">
							<li class="trail-item trail-begin">
								<a href="index.php"><font style="font-size:15px;">Home</font></a>
							</li>
							<li class="trail-item trail-end active">
								<a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-size:15px;">Profile Page</font></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="content-area content-blog col-lg-9 col-md-8 col-sm-12 col-xs-12">
					<div class="site-main">
						<h3 class="widgettitle">Queries</h3>

<?php
$member=strval($_GET['name']);
if ($r['active'] && $r['username'] == $member) {
?>
<div class="panel-body" style="margin:12px;">
<center>
<div class="col-lg-12">
<?php if($delmsg){ ?>
<div class="alert alert-danger" role="alert">
<strong><font size="3"><?php echo htmlentities($delmsg);?></font></strong></div>
<?php } ?>

<?php 
     if (isset($_GET['pagenum'])) {
            $pageno = $_GET['pagenum'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = $rowlimitqueries['Limits'];
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblenquiry WHERE Name = '$username'";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$id=intval($_GET['id']);
$member=strval($_GET['name']);
$query1q=mysqli_query($con,"Select * from tblenquiry where Name='$member' order by ID desc LIMIT $offset, $no_of_records_per_page");
$cnt=1;
while($row1q=mysqli_fetch_array($query1q)){
?>


<?php
$answer = $row1q["answer"]; 
$answer2 = "No Reply Yet.";
?>

<center>
<div class="col-lg-12">
<div id="sidebar01" style="margin-top:-15px; margin-bottom:25px; border: 2px solid #000; box-shadow: 0 18px 25px -25px rgba(0,0,0,1); border-radius:5px;">
<font size="4" color="#000">Date Submitted:</font> <font size="4" color="grey"> <?php echo $row1q['EnquiryDate'];?></font><br>
<font size="4" color="#000">Message Sent:</font> <font size="4" color="green"> <?php echo $row1q['Message'];?></font><br>
<?php
if (empty($answer)) { 
?>
<font size="4" color="#000">Admin Reply:</font> <font size="4" color="grey"> <?php echo $answer2;?></font><br>
<?php } else 
{ ?>
<font size="4" color="#000">Admin Reply:</font> <font size="4" color="#4682B4"> <?php echo $answer;?></font><br>

<?php } ?>
<a href="profilequeries.php?name=<?php echo $member;?>&id=<?php echo htmlentities($row1q['ID']);?>&&action=del">&nbsp;<font color="red" size="4"><i class="fa fa-times" aria-hidden="true" style="color: red"></i> <b>Delete</b></font></a></font>
</div><br>
</div>
<?php
}
?>
</div>
</div>
<?php } ?>

</div>
<center>
<?php 
$prevpage = $pageno - 1;
$nextpage = $pageno + 1;
?>
<div class="pagebtn" style="margin-left:330px;margin-top:-130px;">
          <ul class="pagination justify-content-center sm-12">
          <li class="page-item"><a href="?name=<?php echo $member;?>&pagenum=1"  class="page-link">First</a></li>
          <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?name=$member&pagenum=".($pageno - 1); } ?>" class="page-link"><?php echo $prevpage;?></a>
          </li>
    <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?name=$member&pagenum=".($pageno + 1); } ?>" class="page-link" style="padding-left:5pxpadding-right:5px;;"><?php echo $pageno;?></a>
          </li>
          <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?name=$member&pagenum=".($pageno + 1); } ?>" class="page-link"><?php echo $nextpage;?></a>
          </li>
          <li class="page-item"><a href="?name=<?php echo $member;?>&pagenum=<?php echo $total_pages; ?>" class="page-link">Last</a></li>
          </ul>
</div>
</center>
</td>
<br><br>


					
				</div>
				<div class="sidebar sidebar-blog col-lg-3">
					<div class="wrapper-sidebar">
<?php include 'account.php';?>
<?php include 'tab-profile.php';?>	
						
			</div>
		</div>
	</div></div>
	<footer class="footer style7" style="margin-top:50px;">
		<div class="container">
			<div class="container-wapper">
				<div class="row">
					
				<div class="footer-end">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="coppyright">
				Copyright © 2024 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="tanajil-payment">
						<?php 
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4" color="white"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"><i class="fa fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
}
?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
	<script src="assets/js/jquery-1.12.4.min.js"></script>
	<script src="assets/js/jquery.plugin-countdown.min.js"></script>
	<script src="assets/js/jquery-countdown.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/magnific-popup.min.js"></script>
	<script src="assets/js/isotope.min.js"></script>
	<script src="assets/js/jquery.scrollbar.min.js"></script>
	<script src="assets/js/jquery-ui.min.js"></script>
	<script src="assets/js/mobile-menu.js"></script>
	<script src="assets/js/chosen.min.js"></script>
	<script src="assets/js/slick.js"></script>
	<script src="assets/js/jquery.elevateZoom.min.js"></script>
	<script src="assets/js/jquery.actual.min.js"></script>
	<script src="assets/js/fancybox/source/jquery.fancybox.js"></script>
	<script src="assets/js/lightbox.min.js"></script>
	<script src="assets/js/owl.thumbs.min.js"></script>
	<script src="assets/js/jquery.scrollbar.min.js"></script>
	<script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM'></script>
	<script src="assets/js/frontend-plugin.js"></script>
</body>

<!-- tanajil/bloglist.html  21 Nov 2019 03:35:36 GMT -->
</html>