<div class="widget widget-post">
							<h3 class="widgettitle">User Account</h3>
							
<?php if($r['active']) { ?>
<div id="sidebar01" style="box-shadow: 0 20px 25px -25px rgba(0,0,0,1);">
<ul class="tanajil-posts">
<li class="widget-post-item">
									<div class="thumb-blog">
									<img src="admin/postimages/<?php echo $r['profilepic'];?>" style="border-radius: 5px; width:100px;  height:100px;">
									</div>
									<div class="post-content">
										<div class="cat" style="margin-top:10px;">
                                                                                                                                                                                    <h5><font style="font-size:18px; text-shadow: 1px 1px 1px black; margin-top:10px;" color="#4CBB17"><?php echo $r['username'];?></font></h5>
										</div>
                                                                                                                                                                                    <h5 class="post-title"><font style="font-size:15px;"><a href="profile.php?name=<?php echo $r['username'];?>">My Profile</a></font></h5>
                                                                                                                                                                                    <h5 class="post-title"><font style="font-size:15px;"><a href="logout.php">Logout</a></font></h5>
									</div>
</li>
</ul>
</div>
<?php } else { ?>
<div id="sidebar01" style="box-shadow: 0 20px 25px -25px rgba(0,0,0,1);">
<ul class="tanajil-posts">
<li class="widget-post-item">
	                                                                                                                                                <div class="thumb-blog">
									<img src="images/accountlogo.png" style="border-radius: 5px; width:100px;  height:100px;">
									</div>
									<div class="post-content" style="margin-top:8px;">
									                  <h5 class="post-title"><font style="font-size:15px;"><a href="login.php">Login</a></font></h5>
                                                                                                                                                                                    <h5 class="post-title"><font style="font-size:15px;"><a href="register.php">Register</a></font></h5>
                                                                                                                                                                                    <h5 class="post-title"><font style="font-size:15px;"><a href="forgot-password.php">Reset Password</a></font></h5>
									</div>
</li>
</ul>
</div>
<?php } ?>
								
						
							
						</div>