-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: db5016640613.hosting-data.io
-- Generation Time: Nov 14, 2024 at 08:45 PM
-- Server version: 8.0.36
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs13487267`
--

-- --------------------------------------------------------

--
-- Table structure for table `forget_password`
--

CREATE TABLE `forget_password` (
  `id` int NOT NULL,
  `email` varchar(200) NOT NULL,
  `temp_key` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblabout`
--

CREATE TABLE `tblabout` (
  `id` int NOT NULL,
  `AboutTitle` varchar(200) DEFAULT NULL,
  `About1` longtext,
  `About2` longtext,
  `About3` longtext,
  `ClanPic` varchar(255) DEFAULT NULL,
  `Is_Active` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblabout`
--

INSERT INTO `tblabout` (`id`, `AboutTitle`, `About1`, `About2`, `About3`, `ClanPic`, `Is_Active`) VALUES
(1, 'About the Clan', 'Voluptate illum dolore ita ipsum, quid deserunt singulis, labore admodum ita multos malis ea nam nam tamen fore amet.Vidisse quid incurreret ut ut possumus transferrem si ita labore dolor si appellat, aut dolore doctrina. Commodo dolor esse in magna, a a multos senserit nam si aliqua iis multos..', 'Voluptate illum dolore ita ipsum, quid deserunt singulis, labore admodum ita multos malis ea nam nam tamen fore amet.Vidisse quid incurreret ut ut possumus transferrem si ita labore dolor si appellat, aut dolore doctrina. Commodo doloresse in magna, senserit nam si aliqua iis multos. Commodo dolor esse in magna, a a multos senserit nam si aliqua iis multos. Commodo dolor esse in magna.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. ', 'd7a09e775dc606a787bb150fc5bfc956.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int NOT NULL,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`, `CreationDate`, `UpdationDate`) VALUES
(1, 'admin', '$2y$12$qSLk5BXgXKIAgXVREAfy6ePvn97dReBc4PwnRfILl0It2yTYNL8S.', 'admin@admin.com', 1, '2018-05-27 17:51:00', '2024-08-31 10:05:29');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(8, 'Gaming News', 'Gaming News', '2021-09-25 16:39:50', NULL, 1),
(9, 'General News', 'General News', '2021-09-25 16:40:00', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int NOT NULL,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `postId`, `name`, `email`, `comment`, `postingDate`, `status`) VALUES
(125, '23', 'Demo', 'demo@demo.com', 'Test', '2024-07-22 02:37:41', 1),
(136, '23', 'Demo', 'demo@demo.com', 'qwerty', '2024-07-31 17:55:09', 1),
(151, '24', 'Demo', 'admin@desktopcode.com', 'ABC', '2024-08-14 07:59:00', 1),
(159, '24', 'Demo', 'admin@desktopcode.com', '123', '2024-08-21 03:23:50', 1),
(160, '24', 'Demo', 'admin@desktopcode.com', 'COMMENT', '2024-08-29 10:52:30', 1),
(162, '31', 'Demo', 'admin@desktopcode.com', 'TEST COMMENT!', '2024-08-29 11:59:59', 1),
(163, '0', 'Demo', 'admin@desktopcode.com', '123', '2024-08-29 23:37:55', 1),
(164, '0', 'Demo', 'admin@desktopcode.com', '112', '2024-08-29 23:39:41', 1),
(165, '31', 'ONE', 'demo3@demo3.com', '123', '2024-08-30 11:18:03', 1),
(189, '32', 'Demo', 'admin@desktopcode.com', 'TEST!', '2024-09-21 18:24:42', 1),
(219, '32', 'Demo', 'admin@desktopcode.com', 'ABC', '2024-10-23 02:19:44', 1),
(225, '31', 'Demo', 'admin@desktopcode.com', '123', '2024-10-25 12:36:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `id` int NOT NULL,
  `Contact` varchar(255) DEFAULT NULL,
  `ContactInfo` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `EmailAddress` varchar(255) DEFAULT NULL,
  `fromname` varchar(255) DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`id`, `Contact`, `ContactInfo`, `Phone`, `PhoneNumber`, `Email`, `EmailAddress`, `fromname`, `Is_Active`) VALUES
(1, 'Contact Information', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam aliquip.', 'Phone', '123456789', 'Email', 'admin@desktopcode.com', 'Gaming Template Admin Panel', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcss`
--

CREATE TABLE `tblcss` (
  `id` int NOT NULL,
  `CSSName` varchar(200) DEFAULT NULL,
  `CSSURL` mediumtext,
  `Description` mediumtext,
  `Is_Live` int DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcss`
--

INSERT INTO `tblcss` (`id`, `CSSName`, `CSSURL`, `Description`, `Is_Live`, `Is_Active`) VALUES
(25, 'Custom Main', 'css/custom.css', 'Main CSS FILE', 1, 1),
(26, 'Main', 'css/main.css', 'Second Main CSS File', 1, 1),
(28, 'Black', 'css/9black.css', '9', 0, 0),
(29, 'Black2', 'css/9black2.css', '9', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--

CREATE TABLE `tblenquiry` (
  `ID` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Message` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsRead` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblenquiry`
--

INSERT INTO `tblenquiry` (`ID`, `Name`, `Email`, `Message`, `answer`, `EnquiryDate`, `IsRead`) VALUES
(20, 'Demo', 'admin@desktopcode.com', 'HELLO!!! TEST!', 'REPLY! TEST!!!', '2024-08-28 14:37:32', 1),
(36, 'ONE', 'demo3@demo3.com', 'bcfcvb', '', '2024-09-15 12:57:44', 1),
(69, 'Demo', 'admin@desktopcode.com', 'Test!', '', '2024-10-26 15:36:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblereply`
--

CREATE TABLE `tblereply` (
  `id` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Message` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Is_Active` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblereply`
--

INSERT INTO `tblereply` (`id`, `Name`, `Email`, `Message`, `Is_Active`) VALUES
(11, 'Demo', 'thesnodge@live.co.uk', 'ssssssssssssssssssssssssss', 1),
(13, 'rest', 'tes@fduisghfiugh.com', 'asDFSA', 1),
(14, 'Demo', 'tes@fduisghfiugh.com', '123', 1),
(15, 'Demo', 'thesnodge@live.co.uk', 'sdfegdfshjjkjjjj', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblfonts`
--

CREATE TABLE `tblfonts` (
  `id` int NOT NULL,
  `FontName` varchar(200) DEFAULT NULL,
  `FontURL` mediumtext,
  `Description` mediumtext,
  `website` int DEFAULT NULL,
  `admin` int DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfonts`
--

INSERT INTO `tblfonts` (`id`, `FontName`, `FontURL`, `Description`, `website`, `admin`, `Is_Active`) VALUES
(1, 'Roboto', '<link href=\"https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap\" rel=\"stylesheet\">', '.roboto-regular ', 0, 0, 0),
(10, 'Teko', '<link href=\"https://fonts.googleapis.com/css2?family=Teko:wght@300..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(11, 'Titillium Web', '<link href=\"https://fonts.googleapis.com/css2?family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&display=swap\" rel=\"stylesheet\">', '--', 0, 0, 0),
(12, 'Montserrat', '<link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(13, 'Spectral SC', '<link href=\"https://fonts.googleapis.com/css2?family=Spectral+SC:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(14, 'Istok Web', '<link href=\"https://fonts.googleapis.com/css2?family=Istok+Web:ital,wght@0,400;0,700;1,400;1,700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(15, 'Smooch Sans', '<link href=\"https://fonts.googleapis.com/css2?family=Smooch+Sans:wght@100..900&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(16, 'K2D', '<link href=\"https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(17, 'Comfortaa', '<link href=\"https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(18, 'Oxanium', '<link href=\"https://fonts.googleapis.com/css2?family=Oxanium:wght@200..800&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(19, 'Josefin Sans', '<link href=\"https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(20, 'Play', '<link href=\"https://fonts.googleapis.com/css2?family=Play:wght@400;700&display=swap\" rel=\"stylesheet\">', '----', 0, 0, 0),
(21, 'Poppins', '<link href=\"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap\" rel=\"stylesheet\">', '--', 0, 0, 0),
(23, 'Yanone Kaffeesatz', '<link href=\"https://fonts.googleapis.com/css2?family=Mate+SC&family=Yanone+Kaffeesatz:wght@200..700&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0),
(24, 'Bai Jamjuree', '<link href=\"https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap\" rel=\"stylesheet\">', 'Bai Jamjuree', 1, 1, 1),
(25, 'Exo', '<link href=\"https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0),
(26, 'Jura', '<link href=\"https://fonts.googleapis.com/css2?family=Jura:wght@300..700&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblfriends`
--

CREATE TABLE `tblfriends` (
  `ID` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Friend` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Blocked` int DEFAULT '0',
  `Is_Active` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblfriends`
--

INSERT INTO `tblfriends` (`ID`, `Name`, `Friend`, `Blocked`, `Is_Active`) VALUES
(57, 'Demo', 'Demo', 0, 1),
(58, 'Demo', 'ONE', 1, 1),
(59, 'ONE', 'Demo', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblgames`
--

CREATE TABLE `tblgames` (
  `id` int NOT NULL,
  `GameName` varchar(200) DEFAULT NULL,
  `glogo` varchar(255) DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblgames`
--

INSERT INTO `tblgames` (`id`, `GameName`, `glogo`, `Is_Active`) VALUES
(1, 'Counter-Strike 2', '652685ca606c7066ea88a2f7f0ba9286.png', 1),
(6, 'Valorant', 'ec1b654f0446b73aa3cf4346ef0f787b.png', 1),
(7, 'Call of Duty', 'codlogo.png', 1),
(8, 'League of Legends', 'fa61581e862c9ced46cebb018c1d6b9d.jpg', 0),
(9, 'DOTA 2', '1c43dd6f935a026320ac6b551606067b.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblheaders`
--

CREATE TABLE `tblheaders` (
  `id` int NOT NULL,
  `HeaderName` varchar(200) DEFAULT NULL,
  `LeftRight` text,
  `Description` mediumtext,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblheaders`
--

INSERT INTO `tblheaders` (`id`, `HeaderName`, `LeftRight`, `Description`, `Is_Active`) VALUES
(1, 'Home', '1', 'index.php', 1),
(2, 'Team', '2', 'team.php', 1),
(3, 'Results', '3', 'results.php', 1),
(5, 'Fixtures', '4', 'fixtures.php', 1),
(6, 'Sponsors', '5', 'sponsors.php', 1),
(7, 'About', '6', 'about.php', 1),
(8, 'Contact', '7', 'contact.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmail`
--

CREATE TABLE `tblmail` (
  `id` int NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromm` varchar(255) DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmail`
--

INSERT INTO `tblmail` (`id`, `website`, `subject`, `fromm`, `Is_Active`) VALUES
(1, 'https://www.desktopcode.com', 'Password Reset', 'noreply@desktopcode.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmatchup`
--

CREATE TABLE `tblmatchup` (
  `id` int NOT NULL,
  `Enemy` longtext,
  `Time` varchar(255) DEFAULT NULL,
  `GameName` varchar(255) NOT NULL,
  `Maps` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `EnemyURL` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `Is_Active` int DEFAULT NULL,
  `PostImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmatchup`
--

INSERT INTO `tblmatchup` (`id`, `Enemy`, `Time`, `GameName`, `Maps`, `EnemyURL`, `Is_Active`, `PostImage`) VALUES
(6, 'Team A', '19:00 11/10/25', 'Counter-Strike 2', 'de_mirage, de_nuke', 'https://www.desktopcode.com', 1, '80c6465f639c0427b408b6231fdac3cd.png'),
(7, 'Team B', '18:00 11/10/24', 'Counter-Strike 2', 'de_mirage', 'https://www.desktopcode.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(8, 'Team C', '17:30 20/10/24', 'Call of Duty', '---', 'https://www.desktopcode.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(9, 'Team D', '20:00 11/10/27', 'Counter-Strike 2', 'de_dust2', 'https://www.desktopcode.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(12, 'Team E', '18:00 01/10/24', 'Counter-Strike 2', 'de_nuke', 'https://www.google.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(13, 'Team F', '17:00 11/10/2026', 'Valorant', 'Bind', 'https://www.google.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblpagelimits`
--

CREATE TABLE `tblpagelimits` (
  `id` int NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `Limits` text,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpagelimits`
--

INSERT INTO `tblpagelimits` (`id`, `PageName`, `Limits`, `Is_Active`) VALUES
(1, 'News Posts', '3', 1),
(2, 'News Comments', '5', 1),
(3, 'Results', '5', 1),
(4, 'Fixtures', '5', 1),
(5, 'Inbox', '5', 1),
(6, 'Outbox', '5', 1),
(7, 'Profile Comments', '5', 1),
(8, 'Profile Queries', '5', 1),
(9, 'TAB-Results', '5', 1),
(10, 'TAB-Fixtures', '5', 1),
(11, 'TAB-News', '5', 1),
(12, 'TAB-Members', '10', 1),
(13, 'Friends List', '10', 1),
(14, 'Blocked List', '10', 1),
(15, 'Friends Inbox', '10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE `tblposts` (
  `id` int NOT NULL,
  `PostTitle` longtext,
  `CategoryId` int DEFAULT NULL,
  `SubCategoryId` int DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Is_Active` int DEFAULT NULL,
  `PostUrl` mediumtext,
  `PostImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`) VALUES
(16, 'TEST POST NEWS', 8, 0, 'Test post.', '2024-07-14 02:03:13', '2024-10-27 07:31:48', 1, 'TEST-POST-NEWS', 'ee5789ce86a959c5979afe2acb7e0631.png'),
(17, 'DOTA 2 NEWS TEST', 8, 0, 'TESTING!', '2024-07-14 04:45:31', '2024-10-14 15:45:50', 1, 'DOTA-2-NEWS-TEST', '5ea4fb5d6a96ff3d81c8c48e5b84dd18.png'),
(22, 'Testing Post', 8, 0, 'Test Post!', '2024-07-17 22:49:46', NULL, 1, 'Testing-Post', 'd2eb0b5e44d978df91b0d10f99c67caejpeg'),
(23, 'FIFA Example Post', 8, 0, 'FIFA Example Post Details. FIFA Example Post Details. FIFA Example Post Details.', '2024-07-18 16:56:33', '2024-10-14 15:07:29', 1, 'FIFA-Example-Post', '6a76a729f10068835adcd04b3f5c0a23.jpg'),
(24, 'NEW NEWS POST', 9, 0, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', '2024-07-27 16:15:17', '2024-08-07 03:53:49', 1, 'NEW-NEWS-POST', '466e003e36d7f59d68aaa93d750f3f36.png'),
(31, 'Gaming Template Admin Panel', 8, 0, 'Gaming Template Admin Panel Released! Download and play around with 9 FREE templates to go with it!', '2024-08-23 00:31:25', '2024-08-31 05:09:24', 1, 'Gaming-Template-Admin-Panel', '152882321c881f12336469495fe861d0.jpg'),
(32, 'FREE Gaming Template Admin Panel ', 8, 0, 'Gaming Template Admin Panel is now 100% FREE!', '2024-09-10 05:20:48', '2024-09-15 18:14:44', 1, 'FREE-Gaming-Template-Admin-Panel-', 'c636315663f1ec082dd5a7f84bc5fc85.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblprivatemsg`
--

CREATE TABLE `tblprivatemsg` (
  `ID` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Subject` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Receiver` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Message` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Reply` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SentDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsActive` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblprivatemsg`
--

INSERT INTO `tblprivatemsg` (`ID`, `Name`, `Subject`, `Receiver`, `Message`, `Reply`, `SentDate`, `IsActive`) VALUES
(141, 'ONE', 'dasds', 'ONE', 'sdasafgag', '', '2024-09-25 04:54:11', 1),
(220, 'ONE', 'fsdaf', 'ONE', 'fasdf', '', '2024-10-30 10:46:25', 1),
(221, 'ONE', 'ded', 'ONE', 'ddd', '', '2024-10-30 10:49:57', 1),
(223, 'ONE', 'ffs', 'ONE', 'dfsf', '', '2024-10-30 10:51:18', 1),
(224, 'ONE', 'd', 'ONE', 'adsa', '', '2024-10-30 11:04:32', 1),
(225, 'ONE', 'dd', 'ONE', 'dsa', '', '2024-10-30 11:05:51', 1),
(226, 'ONE', 'dsa', 'ONE', 'sdaas', '', '2024-10-30 11:09:36', 1),
(227, 'ONE', 'ddf', 'ONE', 'dfsf', '', '2024-10-30 11:11:20', 1),
(265, 'ONE', 'wdwa', 'ONE', 'dasf', '', '2024-10-30 19:07:20', 1),
(266, 'ONE', 'dd', 'Demo', 'dd', '', '2024-10-30 19:10:01', 1),
(267, 'ONE', 'aa', 'Demo', 'aa', '', '2024-10-30 19:10:10', 1),
(269, 'ONE', 'RE:123134', 'ONE', 'dfgdfh', '', '2024-10-30 19:10:39', 1),
(298, 'Demo', 'fsdf', 'ONE', 'dsff', '', '2024-10-31 16:27:24', 1),
(299, 'Demo', 'asdd', 'ONE', 'sdasd', '', '2024-10-31 16:28:28', 1),
(306, 'ONE', 'fdsf', 'ONE', 'dsfds', '', '2024-10-31 16:39:15', 1),
(312, 'Demo', 'RE:aa', 'ONE', 'dgvdvx', '', '2024-11-02 11:21:01', 1),
(313, 'Demo', 'RE:aa', 'ONE', 'hkl', '', '2024-11-02 11:26:54', 1),
(314, 'Demo', 'RE:dd', 'ONE', '1212', '', '2024-11-02 11:48:08', 1),
(315, 'Demo', 'RE:dd', 'ONE', '1212', '', '2024-11-02 11:49:49', 1),
(316, 'Demo', 'RE:dd', 'ONE', 'dxfvfh', '', '2024-11-02 11:50:37', 1),
(317, 'Demo', 'RE:dd', 'ONE', 'fdxsg', '', '2024-11-02 11:51:31', 1),
(318, 'Demo', 'ddd', 'ONE', 'dddddd', '', '2024-11-02 11:51:57', 1),
(319, 'Demo', 'ff', 'ONE', 'ff', '', '2024-11-02 11:52:34', 1),
(320, 'Demo', 'gg', 'ONE', 'gg', '', '2024-11-02 11:52:51', 1),
(321, 'Demo', 'gg', 'ONE', 'gg', '', '2024-11-02 11:55:43', 1),
(322, 'Demo', 'dd', 'ONE', 'dd', '', '2024-11-02 13:21:53', 1),
(323, 'Demo', 'fgg', 'ONE', 'ggg', '', '2024-11-11 14:46:02', 1),
(324, 'Demo', 'ff', 'ONE', 'fff', '', '2024-11-11 14:46:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblreports`
--

CREATE TABLE `tblreports` (
  `ID` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RUser` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Category` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Message` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsRead` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblreports`
--

INSERT INTO `tblreports` (`ID`, `Name`, `Email`, `RUser`, `Category`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(16, 'Demo', 'admin@desktopcode.com', 'Demo', '123', 'saDF', '2024-10-30 23:46:24', 0),
(17, 'Demo', 'admin@desktopcode.com', 'Demo', 'General', '123', '2024-10-31 17:52:35', 0),
(18, 'Demo', 'admin@desktopcode.com', 'Demo', NULL, 'sdaasdasdf', '2024-10-31 18:43:50', 0),
(19, 'Demo', 'admin@desktopcode.com', 'ONE', NULL, 'test 321', '2024-11-11 14:45:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblresults`
--

CREATE TABLE `tblresults` (
  `id` int NOT NULL,
  `Enemy` longtext,
  `Time` varchar(255) DEFAULT NULL,
  `GameName` varchar(255) NOT NULL,
  `Result` varchar(255) DEFAULT NULL,
  `WScore` varchar(255) DEFAULT NULL,
  `LScore` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `Maps` varchar(255) DEFAULT NULL,
  `EnemyURL` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `Is_Active` int DEFAULT NULL,
  `ClanLogo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblresults`
--

INSERT INTO `tblresults` (`id`, `Enemy`, `Time`, `GameName`, `Result`, `WScore`, `LScore`, `Maps`, `EnemyURL`, `Is_Active`, `ClanLogo`) VALUES
(6, 'Team One', '14:00 12/09/24', 'Counter-Strike 2', 'WIN', '16', '2', 'de_dust2', 'https://www.desktopcode.com', 1, '80c6465f639c0427b408b6231fdac3cd.png'),
(7, 'Team Two', '18:30 10/10/24', 'League of Legends', 'WIN', '2', '0', '-', 'https://www.google.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(8, 'Team Three', '12:00 12/03/25', 'Counter-Strike 2', 'WIN', '16', '7', 'de_dust2', 'https://www.desktopcode.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(10, 'Team Five', '14:00 12/01/25', 'Valorant', 'LOSS', '9', '16', 'Ascent', 'https://www.google.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(18, 'Team Six', '12:00 12/03/25', 'Counter-Strike 2', 'WIN', '16', '1', 'de_inferno', 'https://www.google.com', 1, '0b8a6d41ff44e83bc6de47044294d9c8.png'),
(21, 'Team Seven', '21:00 05/11/24', 'Call of Duty', 'WIN', '3', '1', '', 'https://www.desktopcode.com', 1, '80c6465f639c0427b408b6231fdac3cd.png'),
(22, 'Team Eight', '14:00 12/09/24', 'Counter-Strike 2', 'DRAW', '15', '15', 'de_nuke', 'https://www.desktopcode.com', 1, '80c6465f639c0427b408b6231fdac3cd.png'),
(23, 'Team Nine', '21:00 25/08/24', 'Counter-Strike 2', 'WIN', '16', '9', 'de_cbble', 'https://www.desktopcode.com', 1, '80c6465f639c0427b408b6231fdac3cd.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblsettings`
--

CREATE TABLE `tblsettings` (
  `id` int NOT NULL,
  `SiteTitle` longtext,
  `MetaTags` longtext,
  `Description` longtext,
  `ClanName` varchar(255) NOT NULL,
  `ForumUrl` mediumtext,
  `ClanLogo` varchar(255) DEFAULT NULL,
  `SiteLogo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsettings`
--

INSERT INTO `tblsettings` (`id`, `SiteTitle`, `MetaTags`, `Description`, `ClanName`, `ForumUrl`, `ClanLogo`, `SiteLogo`, `favicon`) VALUES
(1, 'Gaming Template Admin Panel', 'keywords,here,meta,tags,gaming,clan,website,template,desktopcode,code,admin,', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'FUSE', '', 'f50c73d00fda2bd6d78ce4082e70f008.png', 'a35c1acb820023f25d48991846c6b50e.png', 'f50c73d00fda2bd6d78ce4082e70f008.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblsocial`
--

CREATE TABLE `tblsocial` (
  `id` int NOT NULL,
  `SocialMedia` varchar(200) DEFAULT NULL,
  `URL` mediumtext,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsocial`
--

INSERT INTO `tblsocial` (`id`, `SocialMedia`, `URL`, `Is_Active`) VALUES
(2, 'pinterest', 'https://www.pinterest.com', 0),
(3, 'youtube', 'https://www.youtube.com', 1),
(4, 'twitter', 'https://www.twitter.com', 1),
(7, 'instagram', 'https://www.instagram.com', 0),
(10, 'twitch', 'https://www.twitch.tv', 1),
(11, 'facebook', 'https://www.facebook.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsponsors`
--

CREATE TABLE `tblsponsors` (
  `id` int NOT NULL,
  `Sponsor` varchar(200) DEFAULT NULL,
  `SponsorDescription` mediumtext,
  `SponsorImage` varchar(255) DEFAULT NULL,
  `SponsorURL` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsponsors`
--

INSERT INTO `tblsponsors` (`id`, `Sponsor`, `SponsorDescription`, `SponsorImage`, `SponsorURL`, `Is_Active`) VALUES
(7, 'Sponsor Name 1', '', 'f562b4548d243ef53e9c3952f090010f.png', 'https://www.desktopcode.com', 1),
(8, 'Sponsor Name 2', '', 'a35c1acb820023f25d48991846c6b50e.png', 'https://www.desktopcode.com', 1),
(9, 'Sponsor Name 3', '', 'e688363e9353957f5ccb685e0c90fea8.png', 'https://www.desktopcode.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

CREATE TABLE `tblsubcategory` (
  `SubCategoryId` int NOT NULL,
  `CategoryId` int DEFAULT NULL,
  `Subcategory` varchar(255) DEFAULT NULL,
  `SubCatDescription` mediumtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbltabnames`
--

CREATE TABLE `tbltabnames` (
  `id` int NOT NULL,
  `TabName` mediumtext,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltabnames`
--

INSERT INTO `tbltabnames` (`id`, `TabName`, `Is_Active`) VALUES
(1, 'News', 1),
(2, 'Results', 1),
(3, 'Fixtures', 1),
(4, 'Members', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbltabs`
--

CREATE TABLE `tbltabs` (
  `id` int NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `TabName` mediumtext,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltabs`
--

INSERT INTO `tbltabs` (`id`, `PageName`, `TabName`, `Is_Active`) VALUES
(1, 'Home Top', 'Results', 1),
(2, 'Home Bottom', 'Fixtures', 1),
(3, 'Team Top', 'News', 1),
(4, 'Team Bottom', 'Members', 1),
(5, 'Results Top', 'News', 1),
(6, 'Results Bottom', 'Members', 1),
(7, 'Fixtures Top', 'Members', 1),
(8, 'Fixtures Bottom', 'News', 1),
(9, 'Sponsors Top', 'Members', 1),
(10, 'Sponsors Bottom', 'News', 1),
(11, 'About Top', 'Results', 1),
(12, 'About Bottom', 'News', 1),
(13, 'Contact Top', 'Members', 1),
(14, 'Contact Bottom', 'News', 1),
(15, 'News Top', 'News', 1),
(16, 'News Bottom', 'DIsabled', 1),
(17, 'Profile Top', 'Results', 1),
(18, 'Profile Bottom', 'News', 1),
(19, 'Member Top', 'Members', 1),
(20, 'Member Bottom', 'News', 1),
(21, 'Register Top', 'Results', 1),
(22, 'Register Bottom', 'News', 1),
(23, 'Login Top', 'Results', 1),
(24, 'Login Bottom', 'News', 1),
(25, 'Forgot Top', 'News', 1),
(26, 'Forgot Bottom', 'Members', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblteam`
--

CREATE TABLE `tblteam` (
  `id` int NOT NULL,
  `Name` longtext,
  `Alias` varchar(255) DEFAULT NULL,
  `Game` varchar(255) NOT NULL,
  `FavMap` varchar(255) DEFAULT NULL,
  `FavWeapon` varchar(255) DEFAULT NULL,
  `Sensitivity` varchar(255) DEFAULT NULL,
  `Resolution` varchar(255) DEFAULT NULL,
  `Mouse` varchar(255) DEFAULT NULL,
  `Keyboard` varchar(255) DEFAULT NULL,
  `Headset` varchar(255) DEFAULT NULL,
  `About` varchar(255) DEFAULT NULL,
  `Is_Active` int DEFAULT NULL,
  `Avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblteam`
--

INSERT INTO `tblteam` (`id`, `Name`, `Alias`, `Game`, `FavMap`, `FavWeapon`, `Sensitivity`, `Resolution`, `Mouse`, `Keyboard`, `Headset`, `About`, `Is_Active`, `Avatar`) VALUES
(2, 'Member One', 'ONE', 'Counter-Strike 2', 'de_dust2', 'AK47', '2.5 & 800 DPI', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, 'dacfad0ca86ac0ec30befe55e3430fde.png'),
(3, 'Member Two', 'TWO', 'Counter-Strike 2', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(4, 'Member Three', 'THREE', 'Counter-Strike 2', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(5, 'Member Four', 'FOUR', 'Counter-Strike 2', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(24, 'Member Five', 'FIVE', 'Counter-Strike 2', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(25, 'Member Six', 'SIX', 'Valorant', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(26, 'Member Seven', 'SEVEN', 'Valorant', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(27, 'Member Eight', 'EIGHT', 'Call of Duty', 'de_dust2', 'AK47', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Information about the player.....', 1, 'f50c73d00fda2bd6d78ce4082e70f008.png'),
(29, 'User Demo', 'Demo', 'Counter-Strike 2', 'de_dust2', 'AK47 & Deagle', '2.5', '2048 by 1440', 'Mouse', 'Keyboard', 'Headset', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, 'dacfad0ca86ac0ec30befe55e3430fde.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblwinlossdraw`
--

CREATE TABLE `tblwinlossdraw` (
  `id` int NOT NULL,
  `resultname` varchar(200) DEFAULT NULL,
  `Is_Active` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblwinlossdraw`
--

INSERT INTO `tblwinlossdraw` (`id`, `resultname`, `Is_Active`) VALUES
(1, 'WIN', 1),
(2, 'LOSS', 1),
(3, 'DRAW', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usermanagement`
--

CREATE TABLE `usermanagement` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profilepic` varchar(255) NOT NULL,
  `verification_key` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `forgot_status` tinyint(1) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usermanagement`
--

INSERT INTO `usermanagement` (`id`, `username`, `email`, `password`, `profilepic`, `verification_key`, `active`, `forgot_status`, `isAdmin`) VALUES
(1, 'Demo', 'admin@desktopcode.com', 'f0258b6685684c113bad94d91b8fa02a', 'dacfad0ca86ac0ec30befe55e3430fde.png', 'f0258b6685684c113bad94d91b8fa02a', 1, 0, 0),
(6, 'demo2', 'DEMO2@DEMO.COM', 'fe01ce2a7fbac8fafaed7c982a04e229', '', '1066726e7160bd9c987c9968e0cc275a', 1, 0, 0),
(7, 'ONE', 'demo3@demo3.com', 'f0258b6685684c113bad94d91b8fa02a', 'f50c73d00fda2bd6d78ce4082e70f008.png', '6bbbd8ef0467357886c90bd4c8020f5e', 1, 0, 0),
(12, 'demoooo', 'randomemail@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'desktopcode-logo.png', 'fb2a202f19f8465b4f96ab52060a2086', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `forget_password`
--
ALTER TABLE `forget_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblabout`
--
ALTER TABLE `tblabout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcss`
--
ALTER TABLE `tblcss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblereply`
--
ALTER TABLE `tblereply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblfonts`
--
ALTER TABLE `tblfonts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblfriends`
--
ALTER TABLE `tblfriends`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblgames`
--
ALTER TABLE `tblgames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblheaders`
--
ALTER TABLE `tblheaders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmail`
--
ALTER TABLE `tblmail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmatchup`
--
ALTER TABLE `tblmatchup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpagelimits`
--
ALTER TABLE `tblpagelimits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblprivatemsg`
--
ALTER TABLE `tblprivatemsg`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblreports`
--
ALTER TABLE `tblreports`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblresults`
--
ALTER TABLE `tblresults`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsettings`
--
ALTER TABLE `tblsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsocial`
--
ALTER TABLE `tblsocial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsponsors`
--
ALTER TABLE `tblsponsors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltabnames`
--
ALTER TABLE `tbltabnames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltabs`
--
ALTER TABLE `tbltabs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblteam`
--
ALTER TABLE `tblteam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblwinlossdraw`
--
ALTER TABLE `tblwinlossdraw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usermanagement`
--
ALTER TABLE `usermanagement`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `forget_password`
--
ALTER TABLE `forget_password`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tblabout`
--
ALTER TABLE `tblabout`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblcss`
--
ALTER TABLE `tblcss`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `tblereply`
--
ALTER TABLE `tblereply`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblfonts`
--
ALTER TABLE `tblfonts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblfriends`
--
ALTER TABLE `tblfriends`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `tblgames`
--
ALTER TABLE `tblgames`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblheaders`
--
ALTER TABLE `tblheaders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblmail`
--
ALTER TABLE `tblmail`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblmatchup`
--
ALTER TABLE `tblmatchup`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblpagelimits`
--
ALTER TABLE `tblpagelimits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblposts`
--
ALTER TABLE `tblposts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tblprivatemsg`
--
ALTER TABLE `tblprivatemsg`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;

--
-- AUTO_INCREMENT for table `tblreports`
--
ALTER TABLE `tblreports`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblresults`
--
ALTER TABLE `tblresults`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblsocial`
--
ALTER TABLE `tblsocial`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblsponsors`
--
ALTER TABLE `tblsponsors`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbltabnames`
--
ALTER TABLE `tbltabnames`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbltabs`
--
ALTER TABLE `tbltabs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblteam`
--
ALTER TABLE `tblteam`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tblwinlossdraw`
--
ALTER TABLE `tblwinlossdraw`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usermanagement`
--
ALTER TABLE `usermanagement`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
